# Test Configurations

1. Config 1: This is Ideal scenario with No Drops and No Reordering.
2. Config 2: This is Modest Loss scenario (2\% loss) and No Reordering.
3. Config 3: This is Modest Loss and Modest Reordering Scenarios (Both 2\%).

You are encouraged to create and test your own configuration files.
